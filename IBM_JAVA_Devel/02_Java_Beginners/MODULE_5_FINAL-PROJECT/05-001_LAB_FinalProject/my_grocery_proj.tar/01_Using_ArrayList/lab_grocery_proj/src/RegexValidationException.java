public class RegexValidationException extends Exception {

    public RegexValidationException(String message) {

        super(message);

    }
    
}

