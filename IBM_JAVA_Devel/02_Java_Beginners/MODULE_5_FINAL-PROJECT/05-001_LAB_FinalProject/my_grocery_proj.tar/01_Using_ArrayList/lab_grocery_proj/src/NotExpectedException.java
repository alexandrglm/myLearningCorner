public class NotExpectedException extends Exception {

    public NotExpectedException(String message) {

        super(message);

    }
    
}
