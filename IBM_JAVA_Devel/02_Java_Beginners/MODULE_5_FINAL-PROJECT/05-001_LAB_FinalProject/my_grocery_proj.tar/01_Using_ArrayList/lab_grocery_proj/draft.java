// /*

// // Almacen en una matriz, precios y cantidades una función parse
// String[][] almacen = {
//     {"Tomate", "Pera", "Kiwi", "Limon", "Manzana" },
//     {"1.50", "0.70", "2.20", "0.45", "1.00"},
//     {"3245", "127", "32", "200", "1414"}
// }


// // CUantas peras hay?
// almacen[2][1]

// // QUiero 7 manzanas
// // Hay manzanas?
// // Hay 7 manzanas?
// // Cuanto cuestan 7 manzanas?
// almacen[0][4] equalsIgonerCase ("manzanas") = producto
// almacen[2][4] parseInt() = int consulta; if !consulta <= 7 "no hay tanta cantidad" else int preCart = consulta ; float preCartPrecio = preCart * cantidad; "Quiere %i %s, a %f € la unidad, total %f?", cantidad, producto, precio, preCart;





// */




// class Product implements Cloneable {

//     // init
//     private String itemName;
//     private float itemPrice;



//     // constructor
//     public Product(String itemName, float itemPrice) {

//         this.itemName = itemName;
//         this.itemPrice = itemPrice;


//     }


//     // Getters Setters
//     public String getItemname(){

//         return itemName;

//     }
//     public void setItemname(String itemName){

//         this.itemName = itemName;
//     }

//     public float getItemprice(){

//         return itemPrice;

//     }
//     public void setItemprice(float itemPrice){

//         this.itemPrice = itemPrice;
//     }


//     // Overrides
// }


// // MAIN CLASS
// public class GroceryStore {

//     // Main method
//     public static void main(String[] args){


//         Scanner sc = new Scanner(System.in);

//         // main menu
//         /*

//         1. Enter ItemName to array
//         2. Enter ItemPrice to array
//         3. Enter Quantity to Array
//         Estos tres se almacenan en una matrix



//         */



//     }



// }

