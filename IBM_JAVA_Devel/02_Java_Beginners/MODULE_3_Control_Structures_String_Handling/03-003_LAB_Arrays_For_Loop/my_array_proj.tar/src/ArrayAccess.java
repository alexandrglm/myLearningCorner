/*
 * IBM Java Certification > Course 2 'Java Beginners'
 * Lab Exercise -> Module 3 > 03-003 'Array Creation and Accessing'
 * 
 * 01 - Array Creation - Accessing
 * 
 */

 public class ArrayAccess {

    public static void main (String s[]) {

        int years[] = {2025,2026,2027,2028,2029,2030};

        System.out.println(years[0]);
        System.out.println(years[1]);
        System.out.println(years[2]);
        System.out.println(years[3]);
        System.out.println(years[4]);
        System.out.println(years[5]);


    }    

}
