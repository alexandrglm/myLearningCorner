public class MyFirstProgram {

    public static void main(String s[]) {

        System.out.println("Hello World!\n");

        System.out.println("Welcome to Java Programming!!");

    }

}