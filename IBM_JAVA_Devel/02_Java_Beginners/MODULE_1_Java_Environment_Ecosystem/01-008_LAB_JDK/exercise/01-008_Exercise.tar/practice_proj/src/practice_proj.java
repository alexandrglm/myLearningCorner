public class practice_proj {

    public static void main(String s[]) {

        System.out.println("Now I Can Write a Java program On My Own!");

    }

}