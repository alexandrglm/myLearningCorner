/* *****************************************************************************
 *  Name:              Alexander Gomez
 *  Coursera User ID:  749357c739894c3fed50b8c38d1578c7
 *  Last modified:     November 7, 2025
 **************************************************************************** */

// package src;

public class HelloWorld {

    public static void main(String[] args) {

        System.out.println("Hello, World");

    }
}
